<?php
/**
 * PHP Array for Korean words
 * Original word list from http://bulbapedia.bulbagarden.net/wiki/List_of_censored_words_in_Generation_V
 */
array_push($badwords,
		'강간',     		// Rape
		'개새끼',     	// Son of a bitch
		'개지랄',     	// Careless dog (insult)
		'걸레같은년',    	// A bitch that is a rag
		'걸레년',    		// Insult for women
		'귀두',    		// Glans penis
		'빨아',    		// To suck
		'핥아',    		// To lick
		'니미랄',    		// An insulting word
		'딸딸이',    		// Masturbation
		'미친년',    		// Crazy bitch
		'미친놈',    		// Crazy bastard
		'병신',    		// Retard
		'보지',    		// Vulva
		'부랄',    		// Same pronunciation as the word for testicles
		'불알',    		// Testicles
		'빠구리',    		// Sexual relationship (slang)
		'빠굴이',    		// Same pronunciation as slang for sexual relationship
		'사까시',     	// Oral sex
		'꼡성감대',     	// Any body part that reacts to sexual stimuli
		'성관계',     	// Sexual relationship
		'냕성폭행',     	// Sexual assult
		'성행위',     	// Sexual act
		'섹스',     		// Sex
		'시팔년',     	// An insult (for women)
		'시팔놈',     	// An insult (for men)
		'쌍넘',     		// An insult (for men)
		'쌍년',     		// An insult (for women)
		'쌍놈',     		// An insult (for men)
		'쌍뇬',     		// An insult (for men)
		'씨발',     		// Shit
		'씨발넘',     	// An insult (for men)
		'씨발년',     	// An insult (for women)
		'씨발놈',     	// An insult (for men)
		'씨발뇬',     	// An insult (for men)
		'씹새끼',     	// Bastard
		'염병',			// Typhoid fever (slang)
		'오르',     		// Orgasm
		'왕자지',     	// Penis
		'유두',     		// Nipple
		'자지',     		// Penis (slang)
		'잠지',     		// Penis
		'정액',     		// Semen
		'창녀',     		// Prostitute
		'콘돔',     		// Condom
		'클리토리스',    	// Clitoris
		'페니스',    		// Penis
		'후장'    		// Gut
);