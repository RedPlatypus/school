<?php
/**
 * PHP Array for Spanish words
 * Original word list from http://bulbapedia.bulbagarden.net/wiki/List_of_censored_words_in_Generation_V
 */
array_push($badwords,
		'bollera',		// Lesbian
		'cabron',		// Dickhead
		'cabrón',		// Dickhead
		'cabrona',		// Dickhead (feminine)
		'cabronazo',	// Bastard
		'capulla',		// Asshole (feminine)
		'capullo',		// Asshole
		'chichi',		// Pussy
		'chocho',		// Pussy
		'cojon',		// Testicle (slang)
		'cojón',		// Testicle (slang)
		'cojones',		// Testicles (slang)
		'comepollas',	// Cocksucker
		'cono',			// Cunt
		'coño',			// Cunt
		'culo',			// Ass
		'follar',		// Fuck
		'follen',		// Go fuck
		'furcia',		// Whore
		'gilipollas',	// Jerk
		'hijaputa',		// Son of a bitch (feminine)
		'hijo puta',	// Son of a bitch
		'hijoputa',		// Son of a bitch
		'hostia',		// Bastard, shit, to hit
		'joder',		// Fuck
		'jodete',		// Go fuck yourself
		'jódete',		// Go fuck yourself
		'joputa',		// Abbreviation of "hijo de puta" (son of a bitch)
		'mamada',		// Blowjob
		'mamon',		// Sucker
		'mamón',		// Sucker
		'mamona',		// Sucker (feminine)
		'marica',		// Faggy
		'maricon',		// Faggot
		'maricón',		// Faggot
		'maricona',		// Drag queen, lesbian
		'mariconazo',	// Faggot
		'nazi',			// Nazi
		'ojete',		// Anus (slang)
		'ostia',		// Abbreviation of "hostia" (bastard, shit, to hit)
		'pajillero',	// Wanker
		'pendon',		// Slob
		'pendón',		// Slob
		'picha',		// Dick
		'polla',		// Dick
		'pollon',		// Dick
		'pollón',		// Dick
		'polvo',		// To ejaculate
		'potorro',		// Vagina
		'puta',			// Bitch/whore
		'puto',			// Bitch/whore (masculine), faggot
		'puton',		// Bitch/whore
		'putón',		// Bitch/whore
		'tortillera',	// Lesbian
		'zorron',		// To be/act slutty
		'zorrón'		// To be/act slutty
);