<?php
/**
 * PHP Array for French words
 * Original word list from http://bulbapedia.bulbagarden.net/wiki/List_of_censored_words_in_Generation_V
 */
array_push($badwords,
		'abruti', 		// Idiot (masculine)
		'abrutie', 		// Idiot (feminine)
		'baise',		// Fuck
		'baisé',		// Fucked
		'baiser',		// To fuck
		'batard',		// Bastard
		'bite',			// Dick
		'bougnoul',		// Sandnigger
		'branleur',		// Wanker
		'burne',		// Testicle
		'chier',		// To shit
		'cocu',			// Cuckold
		'con',			// Idiot
		'connard',		// Idiot
		'connasse',		// Stupid and annoying girl
		'conne',		// Idiot (feminine)
		'couille',		// Ball (testicle)
		'couillon',		// Stupid (masculine)
		'couillonne',	// Stupid (feminine)
		'crevard',		// Backstabber or Hobo, depending on the context
		'cul',			// Ass
		'encule',		// Mother-fucker (masculine)
		'enculé',		// Mother-fucker (masculine)
		'enculee',		// Mother-fucker (feminine)
		'enculée',		// Mother-fucker (feminine)
		'enculer',		// To fuck in the ass
		'enfoire',		// Bastard (masculine)
		'enfoiré',		// Bastard (masculine)
		'fion',			// Ass
		'foutre',		// Cum
		'merde',		// Shit
		'negre',		// Nigger (masculine)
		'nègre',		// Nigger (masculine)
		'negresse',		// Nigger (feminine)
		'négresse',		// Nigger (feminine)
		'nique',		// Fuck
		'niquer',		// To fuck
		'partouze',		// Sex orgy
		'pd',			// Fag
		'pede',			// Fag
		'pédé',			// Fag
		'petasse',		// Slut/Show-off (feminine)
		'pétasse',		// Slut/Show-off (feminine)
		'pine',			// Dick
		'pouffe',		// Show-off (feminine)
		'pouffiasse',	// Show-off (feminine)
		'putain',		// Slut
		'pute',			// Slut
		'salaud',		// Bastard/backstabber (masculine)
		'salop',		// Bastard/backstabber (masculine)
		'salopard',		// Bastard/backstabber (masculine)
		'salope',		// Slut (feminine)
		'sodomie',		// Sodomy
		'sucer',		// To suck
		'tapette',		// Fag
		'tare',			// Insane
		'taré',			// Insane
		'vagin',		// Vagina
		'zob'			// Dick
);